package com.kotamobagu.absensi.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AbsensiDao {
    @Query("SELECT * FROM Karyawan") fun getAllKaryawan(): Flow<List<Karyawan>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertKaryawan(k: Karyawan)
    @Query("SELECT * FROM Absensi WHERE tanggal = :tgl") fun getByDate(tgl: String): Flow<List<Absensi>>
    @Query("SELECT * FROM Absensi WHERE strftime('%Y-%m', tanggal) = :bulan") fun getByMonth(bulan: String): Flow<List<Absensi>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAbsensi(a: Absensi)
    @Update suspend fun updateAbsensi(a: Absensi)
}

@Database(entities=[Karyawan::class, Absensi::class], version=1)
abstract class AppDatabase: RoomDatabase() { abstract fun dao(): AbsensiDao }
