package com.kotamobagu.absensi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.kotamobagu.absensi.ui.*
import androidx.room.Room
import com.kotamobagu.absensi.data.AppDatabase

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(this, AppDatabase::class.java, "absensi.db").fallbackToDestructiveMigration().build()
        setContent {
            MaterialTheme {
                val nav = rememberNavController()
                Scaffold(bottomBar = { BottomNav(nav) }) { pad ->
                    Box(Modifier.padding(pad)) {
                        NavHost(nav, startDestination="home") {
                            composable("home") { HomeScreen(db) }
                            composable("absen") { AbsenScreen(db) }
                            composable("riwayat") { RiwayatScreen(db) }
                            composable("gaji") { GajiScreen(db) }
                            composable("admin") { AdminScreen(db) }
                        }
                    }
                }
            }
        }
    }
}
