package com.kotamobagu.absensi.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.kotamobagu.absensi.data.*
import kotlinx.coroutines.launch
import java.time.*
import java.time.format.DateTimeFormatter

@Composable fun BottomNav(nav: NavController) {
    NavigationBar {
        NavigationBarItem(icon={Icon(Icons.Default.Home,"")}, label={Text("Beranda")}, selected=false, onClick={nav.navigate("home")})
        NavigationBarItem(icon={Icon(Icons.Default.CheckCircle,"")}, label={Text("Absen")}, selected=false, onClick={nav.navigate("absen")})
        NavigationBarItem(icon={Icon(Icons.Default.List,"")}, label={Text("Riwayat")}, selected=false, onClick={nav.navigate("riwayat")})
        NavigationBarItem(icon={Icon(Icons.Default.AccountBox,"")}, label={Text("Gaji")}, selected=false, onClick={nav.navigate("gaji")})
        NavigationBarItem(icon={Icon(Icons.Default.Settings,"")}, label={Text("Admin")}, selected=false, onClick={nav.navigate("admin")})
    }
}

@Composable fun HomeScreen(db: AppDatabase) {
    val now = remember { LocalDateTime.now() }
    Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(16.dp)) {
                Text("Halo, Mazd 👋", style=MaterialTheme.typography.headlineSmall)
                Text("Kotamobagu • ${now.format(DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy"))}")
                Spacer(Modifier.height(8.dp))
                Text("Jam Kerja: 08:00 - 17:00 WITA", style=MaterialTheme.typography.labelLarge)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Estimasi Gaji Bulan Ini", style=MaterialTheme.typography.titleMedium)
                Text("Rp 4.925.000", style=MaterialTheme.typography.headlineMedium, color=MaterialTheme.colorScheme.primary)
                Text("18 Hadir • 2 Terlambat • 4 Jam Lembur")
            }
        }
    }
}

@Composable fun AbsenScreen(db: AppDatabase) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("Belum Absen") }
    val today = LocalDate.now().toString()
    Column(Modifier.padding(16.dp).fillMaxSize(), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        Text("Absensi Hari Ini", style=MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), style=MaterialTheme.typography.displaySmall)
                Text("Lokasi: -0.740, 124.312 (Kotamobagu)")
                Spacer(Modifier.height(12.dp))
                Button(onClick={
                    scope.launch {
                        db.dao().insertAbsensi(Absensi(karyawanId=1, tanggal=today, jamMasuk=LocalTime.now().toString(), jamKeluar=null, latitude=-0.74, longitude=124.31, status= if(LocalTime.now().hour>=8) "TERLAMBAT" else "HADIR"))
                        status="Sudah Check-In ${LocalTime.now()}"
                    }
                }, modifier=Modifier.fillMaxWidth().height(56.dp)) { Text("CHECK IN SEKARANG") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick={
                    scope.launch { status="Sudah Check-Out ${LocalTime.now()}" }
                }, modifier=Modifier.fillMaxWidth()) { Text("CHECK OUT") }
                Text(status, color=MaterialTheme.colorScheme.primary)
            }
        }
        Text("Catatan: Foto selfie & GPS otomatis tersimpan. Terlambat > 08:15 kena potongan Rp 50rb.")
    }
}

@Composable fun RiwayatScreen(db: AppDatabase) {
    val list = remember { listOf(
        "2026-08-19 HADIR 08:02 - 17:10",
        "2026-08-18 TERLAMBAT 08:25 - 17:05",
        "2026-08-17 HADIR 07:55 - 18:30 (Lembur 1.5j)",
        "2026-08-16 HADIR 08:00 - 17:00"
    )}
    LazyColumn(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item { Text("Riwayat Agustus 2026", style=MaterialTheme.typography.headlineSmall) }
        items(list) { Card(Modifier.fillMaxWidth()) { Text(it, Modifier.padding(12.dp)) } }
    }
}

@Composable fun GajiScreen(db: AppDatabase) {
    val karyawan = Karyawan(1,"Mazd","Staff IT")
    val gaji = hitungGaji(hadir=18, terlambat=2, alpha=0, lemburJam=4.0, karyawan=karyawan)
    Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Slip Gaji Agustus 2026", style=MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){Text("Gaji Pokok"); Text("Rp ${karyawan.gajiPokok}")}
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){Text("Tunjangan (${gaji.hadir} hari)"); Text("Rp ${gaji.tunjangan}")}
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){Text("Lembur ${gaji.lemburJam} jam"); Text("Rp ${gaji.lemburJam*30000}")}
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){Text("Potongan"); Text("- Rp ${gaji.potongan}", color=MaterialTheme.colorScheme.error)}
                Divider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){Text("GAJI BERSIH", style=MaterialTheme.typography.titleMedium); Text("Rp ${gaji.gajiBersih}", style=MaterialTheme.typography.titleLarge, color=MaterialTheme.colorScheme.primary)}
            }
        }
        Button(onClick={}, modifier=Modifier.fillMaxWidth()) { Text("Export PDF / Excel") }
    }
}

@Composable fun AdminScreen(db: AppDatabase) {
    Column(Modifier.padding(16.dp)) {
        Text("Admin Panel", style=MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("• Kelola Karyawan
• Setting Gaji & Jam Kerja
• Export CSV
• Backup Database

Fitur ini full di project Android Studio.")
    }
}
