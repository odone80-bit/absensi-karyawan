package com.kotamobagu.absensi.data
import androidx.room.*
import java.time.LocalDate

@Entity
data class Karyawan(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nama: String,
    val jabatan: String,
    val gajiPokok: Long = 4500000,
    val uangMakan: Long = 25000,
    val uangTransport: Long = 20000
)

@Entity(foreignKeys = [ForeignKey(entity=Karyawan::class, parentColumns=["id"], childColumns=["karyawanId"])])
data class Absensi(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val karyawanId: Int,
    val tanggal: String, // yyyy-MM-dd
    val jamMasuk: String?,
    val jamKeluar: String?,
    val latitude: Double?,
    val longitude: Double?,
    val status: String, // HADIR, TERLAMBAT, ALPHA
    val fotoPath: String? = null,
    val totalJam: Double = 0.0
)

data class GajiResult(
    val hadir: Int, val terlambat: Int, val alpha: Int,
    val lemburJam: Double, val tunjangan: Long,
    val potongan: Long, val gajiBersih: Long
)

fun hitungGaji(hadir: Int, terlambat: Int, alpha: Int, lemburJam: Double, karyawan: Karyawan): GajiResult {
    val tunjangan = hadir * (karyawan.uangMakan + karyawan.uangTransport)
    val potLambat = terlambat * 50000L
    val potAlpha = alpha * 100000L
    val lembur = (lemburJam * 30000).toLong()
    val bersih = karyawan.gajiPokok + tunjangan + lembur - potLambat - potAlpha
    return GajiResult(hadir, terlambat, alpha, lemburJam, tunjangan, potLambat+potAlpha, bersih)
}
