# Absensi Karyawan - Android App (Kotamobagu Edition)

Aplikasi Android Native Kotlin + Jetpack Compose untuk Absensi GPS + Perhitungan Gaji Otomatis.

## Fitur
- Check In/Out dengan GPS & Foto Selfie (CameraX)
- Deteksi Terlambat Otomatis
- Hitung Gaji: Pokok + Tunjangan Harian + Lembur - Potongan
- Riwayat & Slip Gaji
- Database Lokal Room + Siap Firebase

## Cara Install
1. Buka Android Studio Hedgehog atau lebih baru
2. Open Project -> pilih folder AbsensiKaryawan
3. Sync Gradle (butuh internet)
4. Run di emulator / HP Android

## Default Karyawan
id=1, nama=Mazd, gajiPokok=4.5jt

## Rumus Gaji
gajiBersih = gajiPokok + (hadir * (uangMakan+uangTransport)) + (lemburJam*30000) - (terlambat*50000) - (alpha*100000)

## Next Dev
- Tambah Firebase Auth & Firestore sync
- Tambah fitur QR Code Kantor
- Face Recognition untuk anti-titip absen
